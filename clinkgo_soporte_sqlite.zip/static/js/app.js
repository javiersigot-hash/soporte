let clientesData = [];
let activeTabId = null;

const tabsHeader = document.getElementById('tabsHeader');
const tabContentArea = document.getElementById('tabContentArea');
const searchInput = document.getElementById('searchInput');
const btnAddTab = document.getElementById('btnAddTab');

// Cargar la lista completa de clientes desde SQLite
async function loadClientes() {
    try {
        const res = await fetch('/api/clientes');
        clientesData = await res.json();
        renderTabs(searchInput.value.toLowerCase());
    } catch (err) {
        console.error("Error cargando clientes:", err);
    }
}

// Renderizar dinámicamente las pestañas y filtrar en base al buscador
function renderTabs(filterTerm = '') {
    tabsHeader.innerHTML = '';
    tabContentArea.innerHTML = '';

    let filtered = clientesData;
    if (filterTerm) {
        filtered = clientesData.filter(c => 
            c.codigo.toLowerCase().includes(filterTerm) || 
            c.contenido.toLowerCase().includes(filterTerm)
        );
    }

    if (filtered.length === 0) {
        tabContentArea.innerHTML = '<p style="color:#666; padding:20px; text-align:center;">No se encontraron resultados de búsqueda.</p>';
        return;
    }

    // Asegurar que haya una pestaña activa válida dentro del filtro
    if (!activeTabId || !filtered.some(c => c.id === activeTabId)) {
        activeTabId = filtered[0].id;
    }

    filtered.forEach((cliente) => {
        // 1. Crear el botón superior de la pestaña
        const btn = document.createElement('button');
        btn.className = `tab-btn ${cliente.id === activeTabId ? 'active' : ''}`;
        btn.textContent = cliente.codigo;
        btn.title = "Doble clic para renombrar";

        // Cambiar de pestaña al hacer clic
        btn.onclick = () => {
            activeTabId = cliente.id;
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.client-data-section').forEach(c => c.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById(`content-${cliente.id}`).classList.add('active');
        };

        // Doble clic para cambiar el código/nombre del cliente
        btn.ondblclick = async function() {
            let nuevoCodigo = prompt("Editar nombre o código del cliente:", cliente.codigo);
            if (nuevoCodigo && nuevoCodigo.trim() !== "" && nuevoCodigo !== cliente.codigo) {
                try {
                    const res = await fetch(`/api/clientes/${cliente.id}`, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ codigo: nuevoCodigo.trim() })
                    });
                    if (res.ok) loadClientes();
                } catch (err) {
                    alert("Error al renombrar el cliente");
                }
            }
        };

        tabsHeader.appendChild(btn);

        // 2. Crear el contenedor de contenido
        const contentDiv = document.createElement('div');
        contentDiv.className = `client-data-section ${cliente.id === activeTabId ? 'active' : ''}`;
        contentDiv.id = `content-${cliente.id}`;

        contentDiv.innerHTML = `
            <div id="editable-wrapper-${cliente.id}" style="display:contents;">
                ${cliente.contenido}
            </div>
            <div class="action-bar">
                <button class="btn-save" onclick="saveContent(${cliente.id})">
                    <i class="fa-solid fa-floppy-disk"></i> Guardar Cambios
                </button>
                <button class="btn-delete" onclick="deleteCliente(${cliente.id})">
                    Eliminar Cliente
                </button>
            </div>
        `;
        tabContentArea.appendChild(contentDiv);
    });
}

// Guardar los datos de la pestaña editada (mantiene texto e imágenes incrustadas)
async function saveContent(id) {
    const wrapper = document.getElementById(`editable-wrapper-${id}`);
    const htmlContenido = wrapper.innerHTML;

    try {
        const res = await fetch(`/api/clientes/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ contenido: htmlContenido })
        });
        if (res.ok) {
            // Actualizar arreglo local en memoria
            const idx = clientesData.findIndex(c => c.id === id);
            if (idx !== -1) clientesData[idx].contenido = htmlContenido;
            alert("Cambios persistidos correctamente en SQLite.");
        }
    } catch (err) {
        alert("Error al intentar guardar.");
    }
}

// Eliminar permanentemente de la base de datos
async function deleteCliente(id) {
    if (confirm("¿Estás completamente seguro de que deseas eliminar este cliente y todos sus datos de soporte?")) {
        try {
            const res = await fetch(`/api/clientes/${id}`, { method: 'DELETE' });
            if (res.ok) {
                activeTabId = null;
                loadClientes();
            }
        } catch (err) {
            alert("Error al intentar eliminar.");
        }
    }
}

// Agregar un nuevo cliente / solapa
btnAddTab.addEventListener('click', async () => {
    const codigo = prompt("Ingresa el identificador/nombre del nuevo cliente (Ej: 401-NUEVOPRO):");
    if (!codigo || codigo.trim() === "") return;

    try {
        const res = await fetch('/api/clientes', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ codigo: codigo.trim() })
        });
        
        if (res.ok) {
            const nuevo = await res.json();
            activeTabId = nuevo.id;
            loadClientes();
        } else {
            const errorData = await res.json();
            alert(errorData.error || "No se pudo añadir el cliente.");
        }
    } catch (err) {
        alert("Error en la conexión con el servidor.");
    }
});

// Buscador reactivo integrado (busca tanto en títulos como dentro de las notas de las solapas)
searchInput.addEventListener('input', (e) => {
    renderTabs(e.target.value.toLowerCase());
});

// Inicialización de la aplicación al cargar
window.addEventListener('DOMContentLoaded', loadClientes);
