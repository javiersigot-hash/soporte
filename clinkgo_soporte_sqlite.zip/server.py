from flask import Flask, jsonify, request, send_from_directory
import sqlite3
import os

app = Flask(__name__, static_folder='static', template_folder='templates')
DB_PATH = 'soporte.db'

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    if not os.path.exists(DB_PATH):
        conn = get_db_connection()
        conn.execute('''
            CREATE TABLE IF NOT EXISTS clientes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                codigo TEXT UNIQUE NOT NULL,
                contenido TEXT
            )
        ''')
        clientes_iniciales = [
            "012-ACSA", "028-AACC", "029-ASSA", "051-ABSA", 
            "058-PANEDILE", "060-CESOP", "071-BAGSA", "075-COPASA", 
            "086-GINSA", "088-ARSAPEM", "110-MEGATLON", "228-OSSE", 
            "255-DPOSS", "338-PEA", "363-OSEBAL", "366-NAT", "396-ARSA"
        ]
        for c in clientes_iniciales:
            slug = c.lower().split('-')[1] if '-' in c else c.lower()
            plantilla = f'''<h3>Datos de Instalación: <span style="color:#1A73E8">{c}</span></h3>
<p style="color: #666; margin-bottom: 15px; font-size: 12px;">Haz clic en el cuadro de abajo para editar textos, IPs, URLs o pegar capturas de pantalla de manera directa.</p>
<div class="editable-area" contenteditable="true">
    <b>IP Servidor:</b> 192.168.X.X<br>
    <b>URL Acceso:</b> https://{slug}.clinkgo.com<br>
    <b>Contacto Técnico:</b> Nombre Completo / Teléfono<br>
    <b>Contraseñas / Accesos:</b> admin / ****<br>
    <b>Notas Adicionales:</b> <br><br>
    <i>(Escribe aquí o pega imágenes directamente de tu portapapeles)</i>
</div>'''
            conn.execute('INSERT INTO clientes (codigo, contenido) VALUES (?, ?)', (c, plantilla))
        conn.commit()
        conn.close()

@app.route('/')
def index():
    return send_from_directory('templates', 'index.html')

@app.route('/api/clientes', methods=['GET'])
def get_clientes():
    conn = get_db_connection()
    rows = conn.execute('SELECT * FROM clientes').fetchall()
    conn.close()
    return jsonify([dict(row) for row in rows])

@app.route('/api/clientes', methods=['POST'])
def add_cliente():
    data = request.json
    codigo = data.get('codigo')
    if not codigo:
        return jsonify({'error': 'El código es obligatorio'}), 400
    
    slug = codigo.lower().split('-')[1] if '-' in codigo else codigo.lower()
    plantilla = f'''<h3>Datos de Instalación: <span style="color:#1A73E8">{codigo}</span></h3>
<p style="color: #666; margin-bottom: 15px; font-size: 12px;">Haz clic en el cuadro de abajo para editar textos, IPs, URLs o pegar capturas.</p>
<div class="editable-area" contenteditable="true">
    <b>IP Servidor:</b> 192.168.X.X<br>
    <b>URL Acceso:</b> https://{slug}.clinkgo.com<br>
    <b>Contacto Técnico:</b> <br>
    <b>Contraseñas:</b> <br>
    <b>Notas:</b> <br>
</div>'''
    
    try:
        conn = get_db_connection()
        cursor = conn.execute('INSERT INTO clientes (codigo, contenido) VALUES (?, ?)', (codigo, plantilla))
        new_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return jsonify({'id': new_id, 'codigo': codigo, 'contenido': plantilla}), 201
    except sqlite3.IntegrityError:
        return jsonify({'error': f'El cliente {codigo} ya existe'}), 400

@app.route('/api/clientes/<int:id>', methods=['PUT'])
def update_cliente(id):
    data = request.json
    codigo = data.get('codigo')
    contenido = data.get('contenido')
    
    conn = get_db_connection()
    if codigo and contenido:
        conn.execute('UPDATE clientes SET codigo = ?, contenido = ? WHERE id = ?', (codigo, contenido, id))
    elif codigo:
        conn.execute('UPDATE clientes SET codigo = ? WHERE id = ?', (codigo, id))
    elif contenido:
        conn.execute('UPDATE clientes SET contenido = ? WHERE id = ?', (contenido, id))
    conn.commit()
    conn.close()
    return jsonify({'status': 'success'})

@app.route('/api/clientes/<int:id>', methods=['DELETE'])
def delete_cliente(id):
    conn = get_db_connection()
    conn.execute('DELETE FROM clientes WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return jsonify({'status': 'success'})

if __name__ == '__main__':
    init_db()
    print("Servidor ClinkGO corriendo en http://localhost:5000")
    app.run(debug=True, port=5000)
